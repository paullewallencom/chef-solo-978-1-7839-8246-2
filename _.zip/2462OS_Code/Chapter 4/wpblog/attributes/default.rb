default.apache.docroot_dir = '/var/www'
default.apache.listen_ports = [80, 443]
default.wpblog.database = 'wpblog'
default.wpblog.db_username = 'wpblog'
default.wpblog.db_password = 'random_password'
